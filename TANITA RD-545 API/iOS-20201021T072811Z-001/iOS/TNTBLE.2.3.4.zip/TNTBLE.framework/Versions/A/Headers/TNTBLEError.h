//
// Copyright (C) 2014. TANITA Corporation.
// All rights reserved.
//

#import <Foundation/Foundation.h>

/// エラードメイン
extern NSString * const TNTBLEErrorDomain;

/**
 * エラーコード
 */
typedef NS_ENUM(NSInteger, TNTBLEError) {
	TNTBLEErrorUnknown           = 0,   // 不明なエラー
	TNTBLEErrorPacketLoss        = 1,   // パケットロス
    TNTBLEErrorChecksum          = 2,   // チェックサムの不合致
    TNTBLEErrorIllegalDeviceType = 3,   // 不正な機器種別
    TNTBLEErrorBusy              = 4,   // 要求を受け付けない状態
};


