//
// Copyright (C) 2014. TANITA Corporation.
// All rights reserved.
//

NSString *const kLibVersion = @"2.3.4";


/**
 * 機器の種類を表します。
 */
typedef NS_ENUM(UInt8, TNTDeviceType) {
    TNTDeviceTypeBodyCompositionMonitor = 0,    // 体組成計
    TNTDeviceTypeActivityMonitor        = 1,    // 活動量計
    TNTDeviceTypeSleepMonitor           = 2,    // 睡眠計
    TNTDeviceTypeBloodPressureMonitor   = 3,    // 血圧計
    TNTDeviceTypeGlucoseMeter           = 4,    // 尿糖計
};

typedef NS_ENUM(UInt8, TNTCountry) {
    TNTCountryJapan = 1,        // 日本
    TNTCountryAsia  = 2,        // アジア
    TNTCountryUSA   = 3,        // アメリカ
    TNTCountryEU    = 4,        // ヨーロッパ
};

typedef NS_OPTIONS(UInt32, TNTUnit) {
    TNTUnitNone     = 0,        // 測定単位なし
    TNTUnitKilogram = 1 << 0,   // キログラム
    TNTUnitPound    = 1 << 1,   // ポンド
    TNTUnitStPound  = 1 << 2,   // ストーンポンド
};

typedef NS_ENUM(UInt8, TNTGender) {
    TNTGenderMale   = 0,        // 男性
    TNTGenderFemale = 1,        // 女性
};

typedef NS_ENUM(UInt8, TNTFigure) {
    TNTFigureNormal     = 0,    // 標準
    TNTFigureAthlete    = 1,    // アスリート
};

typedef NS_ENUM(UInt8, TNTArea) {
    // 海外追加開始
    TNTAreaA0               = 0,
    TNTAreaA1               = 1,
    TNTAreaA2               = 2,
    TNTAreaA3               = 3,
    TNTAreaA4               = 4,
    TNTAreaA5               = 5,
    TNTAreaA6               = 6,
    TNTAreaA7               = 7,
    TNTAreaA8               = 8,
    TNTAreaA9               = 9,
    // 海外追加終了
    
    TNTAreaHokkaido         = 0,    // 北海道
    TNTAreaTohoku           = 1,    // 東北
    TNTAreaHonshuShikoku    = 2,    // 本州（東北除く）＋四国
    TNTAreaKyushu           = 3,    // 九州
    TNTAreaOkinawa          = 4,    // 沖縄
    
    TNTAreaMachine          = 254,  //本体側はこれを見て、本体の地域を返す。
};
