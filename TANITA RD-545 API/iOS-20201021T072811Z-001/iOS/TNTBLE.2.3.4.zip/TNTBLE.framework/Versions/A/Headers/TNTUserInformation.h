//
// Copyright (C) 2014. TANITA Corporation.
// All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TNTType.h"

/**
 * 利用者情報を保持するプロパティクラス
 */
@interface TNTUserInformation : NSObject

/// 個人情報の設定日時を表します。
@property (nonatomic, copy)     NSDate *date;

/// ニックネームを表します。
@property (nonatomic, copy)     NSString *nickname;

/// 生年月日を表します。
@property (nonatomic, copy)     NSDate *dateOfBirth;

/// 性別を表します。
@property (nonatomic)           TNTGender gender;

/// 身長を表します。
@property (nonatomic, copy)     NSString *height;

/// 身長の単位を表します。
@property (nonatomic, readonly) NSString *heightUnit;

/// デバイスで使用する測定単位を表します。
@property (nonatomic)           TNTUnit unit;

/// 体型を表します。
@property (nonatomic)           TNTFigure figure;

/// 生活強度を表します。
@property (nonatomic)           UInt8 activityLevel;

/// 風袋荷重を表します。
@property (nonatomic, copy)     NSString *tare;

/// 風袋荷重の単位を表します。
@property (nonatomic, readonly) NSString *tareUnit;

/// 測定地域を表します。
@property (nonatomic)           TNTArea area;

/// 体重を表します。
@property (nonatomic, copy)     NSString *weight;

/// 体重の単位を表します。
@property (nonatomic, readonly) NSString *weightUnit;

/// 体脂肪率を表します。
@property (nonatomic, copy)     NSString *bodyFat;

/// 体脂肪率の単位を表します。
@property (nonatomic, readonly) NSString *bodyFatUnit;

/// 歩きの歩幅を表します。
@property (nonatomic, copy)     NSString *strideLengthWalking;

/// 歩きの歩幅の単位を表します。
@property (nonatomic, readonly) NSString *strideLengthWalkingUnit;

/// 走りの歩幅を表します。
@property (nonatomic, copy)     NSString *strideLengthRunning;

/// 走りの歩幅の単位を表します。
@property (nonatomic, readonly) NSString *strideLengthRunningUnit;

/// 歩数振分レベルを表します。[0-19]
@property (nonatomic)           UInt8 stepsDistinctionLevel;

@end
