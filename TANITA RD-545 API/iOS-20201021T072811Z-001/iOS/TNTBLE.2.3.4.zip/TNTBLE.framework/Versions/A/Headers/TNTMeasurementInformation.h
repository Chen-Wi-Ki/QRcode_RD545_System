//
// Copyright (C) 2014. TANITA Corporation.
// All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TNTType.h"

/**
 * 測定情報を保持するプロパティクラス
 */
@interface TNTMeasurementInformation : NSObject

/// 体重を表します。
@property (nonatomic, copy)     NSString *weight;

/// 体重の単位を表します。
@property (nonatomic, readonly) NSString *weightUnit;

/// BMIを表します。
@property (nonatomic, copy)     NSString *bodyMassIndex;

/// BMI判定を表します。
@property (nonatomic)           UInt8 bodyMassIndexJudgement;

/// 体脂肪率を表します。
@property (nonatomic, copy)     NSString *bodyFat;

/// 体脂肪率の単位を表します。
@property (nonatomic, readonly) NSString *bodyFatUnit;

/// 体脂肪率判定を表します。
@property (nonatomic)           UInt8 bodyFatJudgement;

/// 左腕の体脂肪率を表します。範囲:5.0～75.0(0.1%単位)。
@property (nonatomic, copy)     NSString *bodyFatLeftArm;

/// 左腕の体脂肪率の単位を表します。
@property (nonatomic, readonly) NSString *bodyFatLeftArmUnit;

/**
 * 左腕の体脂肪率判定を表します。
 * 範囲:1～5(1:やせ，2:-標準，3:+標準，4:軽肥満，5:肥満)。
 */
@property (nonatomic)           UInt8 bodyFatJudgementLeftArm;

/// 右腕の体脂肪率を表します。範囲:5.0～75.0(0.1%単位)。
@property (nonatomic, copy)     NSString *bodyFatRightArm;

/// 右腕の体脂肪率の単位を表します。
@property (nonatomic, readonly) NSString *bodyFatRightArmUnit;

/**
 * 右腕の体脂肪率判定を表します。
 * 範囲:1～5(1:やせ，2:-標準，3:+標準，4:軽肥満，5:肥満)。
 */
@property (nonatomic)           UInt8 bodyFatJudgementRightArm;

/// 左足の体脂肪率を表します。範囲:5.0～75.0(0.1%単位)。
@property (nonatomic, copy)     NSString *bodyFatLeftFoot;

/// 左足の体脂肪率の単位を表します。
@property (nonatomic, readonly) NSString *bodyFatLeftFootUnit;

/**
 * 左足の体脂肪率判定を表します。
 * 範囲:1～5(1:やせ，2:-標準，3:+標準，4:軽肥満，5:肥満)。
 */
@property (nonatomic)           UInt8 bodyFatJudgementLeftFoot;

/// 右足の体脂肪率を表します。範囲:5.0～75.0(0.1%単位)。
@property (nonatomic, copy)     NSString *bodyFatRightFoot;

/// 右足の体脂肪率の単位を表します。
@property (nonatomic, readonly) NSString *bodyFatRightFootUnit;

/**
 * 右足の体脂肪率判定を表します。
 * 範囲:1～5(1:やせ，2:-標準，3:+標準，4:軽肥満，5:肥満)。
 */
@property (nonatomic)           UInt8 bodyFatJudgementRightFoot;

/// 体幹部の体脂肪率を表します。範囲:5.0～75.0(0.1%単位)。
@property (nonatomic, copy)     NSString *bodyFatTrunk;

/// 体幹部の体脂肪率の単位を表します。
@property (nonatomic, readonly) NSString *bodyFatTrunkUnit;

/**
 * 体幹部の体脂肪率判定を表します。
 * 範囲:1～5(1:やせ，2:-標準，3:+標準，4:軽肥満，5:肥満)。
 */
@property (nonatomic)           UInt8 bodyFatJudgementTrunk;

/// 左腕の筋肉量を表します。範囲:0.01～201.60(0.01kg単位)。
@property (nonatomic, copy)     NSString *muscleMassLeftArm;

/// 左腕の筋肉量の単位を表します。
@property (nonatomic, readonly) NSString *muscleMassLeftArmUnit;

/// 左腕の筋肉量スコアを表します。範囲:-4～4(-4～-2:少ない，-1～1:標準，2～4:多い)。
@property (nonatomic)           SInt8 muscleMassScoreLeftArm;

/// 左腕の筋肉量判定を表します。範囲:1～3(1:少ない，2:標準，3:多い)。
@property (nonatomic)           UInt8 muscleMassJudgementLeftArm;

/// 左腕の筋質点数を表します。範囲:0～100(1点単位)。
@property (nonatomic)           UInt8 muscleQualityLeftArm;

/// 左腕の筋質判定を表します。範囲:1～9(1～2:低い，3～7：標準，8～9：高い)。
@property (nonatomic)           UInt8 muscleQualityJudgementLeftArm;

/// 右腕の筋肉量を表します。範囲:0.01～201.60(0.01kg単位)。
@property (nonatomic, copy)     NSString *muscleMassRightArm;

/// 右腕の筋肉量の単位を表します。
@property (nonatomic, readonly) NSString *muscleMassRightArmUnit;

/// 右腕の筋肉量スコアを表します。範囲:-4～4(-4～-2:少ない，-1～1:標準，2～4:多い)。
@property (nonatomic)           SInt8 muscleMassScoreRightArm;

/// 右腕の筋肉量判定を表します。範囲:1～3(1:少ない，2:標準，3:多い)。
@property (nonatomic)           UInt8 muscleMassJudgementRightArm;

/// 右腕の筋質点数を表します。範囲:0～100(1点単位)。
@property (nonatomic)           UInt8 muscleQualityRightArm;

/// 右腕の筋質判定を表します。範囲:1～9(1～2:低い，3～7：標準，8～9：高い)。
@property (nonatomic)           UInt8 muscleQualityJudgementRightArm;

/// 左足の筋肉量を表します。範囲:0.01～201.60(0.01kg単位)。
@property (nonatomic, copy)     NSString *muscleMassLeftFoot;

/// 左足の筋肉量の単位を表します。
@property (nonatomic, readonly) NSString *muscleMassLeftFootUnit;

/// 左足の筋肉量スコアを表します。範囲:-4～4(-4～-2:少ない，-1～1:標準，2～4:多い)。
@property (nonatomic)           SInt8 muscleMassScoreLeftFoot;

/// 左足の筋肉量判定を表します。範囲:1～3(1:少ない，2:標準，3:多い)。
@property (nonatomic)           UInt8 muscleMassJudgementLeftFoot;

/// 左足の筋質点数を表します。範囲:0～100(1点単位)。
@property (nonatomic)           UInt8 muscleQualityLeftFoot;

/// 左足の筋質判定を表します。範囲:1～9(1～2:低い，3～7：標準，8～9：高い)。
@property (nonatomic)           UInt8 muscleQualityJudgementLeftFoot;

/// 右足の筋肉量を表します。範囲:0.01～201.60(0.01kg単位)。
@property (nonatomic, copy)     NSString *muscleMassRightFoot;

/// 右足の筋肉量の単位を表します。
@property (nonatomic, readonly) NSString *muscleMassRightFootUnit;

/// 右足の筋肉量スコアを表します。範囲:-4～4(-4～-2:少ない，-1～1:標準，2～4:多い)。
@property (nonatomic)           SInt8 muscleMassScoreRightFoot;

/// 右足の筋肉量判定を表します。範囲:1～3(1:少ない，2:標準，3:多い)。
@property (nonatomic)           UInt8 muscleMassJudgementRightFoot;

/// 右足の筋質点数を表します。範囲:0～100(1点単位)。
@property (nonatomic)           UInt8 muscleQualityRightFoot;

/// 右足の筋質判定を表します。範囲:1～9(1～2:低い，3～7：標準，8～9：高い)。
@property (nonatomic)           UInt8 muscleQualityJudgementRightFoot;

/// 体幹の筋肉量を表します。範囲:0.01～201.60(0.01kg単位)。
@property (nonatomic, copy)     NSString *muscleMassTrunk;

/// 体幹の筋肉量の単位を表します。
@property (nonatomic, readonly) NSString *muscleMassTrunkUnit;

/// 体幹の筋肉量スコアを表します。範囲:-4～4(-4～-2:少ない，-1～1:標準，2～4:多い)。
@property (nonatomic)           SInt8 muscleMassScoreTrunk;

/// 体幹の筋肉量判定を表します。範囲:1～3(1:少ない，2:標準，3:多い)。
@property (nonatomic)           UInt8 muscleMassJudgementTrunk;

/// 心拍数を表します。範囲:50～200。
@property (nonatomic)           UInt8 epPulse;

/// 心拍数判定を表します。範囲:0～1(0:正常，1:異常)。
@property (nonatomic)           UInt8 epPulseState;

/// アスリート指数を表します。範囲:20～120。
@property (nonatomic)           UInt8 athleteIndex;

/**
 * アスリート判定を表します。
 * 範囲:1～4(1:ビギナー(Beginner)，2:アマチュア(Amateur)，
 * 3:セミアスリート(Semi Athlete)，4:プロアスリート(Pro Athlete))。
 */
@property (nonatomic)           UInt8 athleteJudgement;

/// 左腕50kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceLeftArm50kHzR;

/// 左腕50kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceLeftArm50kHzRUnit;

/// 右腕50kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceRightArm50kHzR;

/// 右腕50kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceRightArm50kHzRUnit;

/// 左足50kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceLeftFoot50kHzR;

/// 左足50kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceLeftFoot50kHzRUnit;

/// 右足50kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceRightFoot50kHzR;

/// 右足50kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceRightFoot50kHzRUnit;

/// 左半身50kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceLeftBody50kHzR;

/// 左半身50kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceLeftBody50kHzRUnit;

/// 右半身50kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceRightBody50kHzR;

/// 右半身50kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceRightBody50kHzRUnit;

/// 両腕50kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceArms50kHzR;

/// 両腕身50kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceArms50kHzRUnit;

/// 左腕50kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceLeftArm50kHzX;

/// 左腕50kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceLeftArm50kHzXUnit;

/// 右腕50kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceRightArm50kHzX;

/// 右腕50kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceRightArm50kHzXUnit;

/// 左足50kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceLeftFoot50kHzX;

/// 左足50kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceLeftFoot50kHzXUnit;

/// 右足50kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceRightFoot50kHzX;

/// 右足50kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceRightFoot50kHzXUnit;

/// 左半身50kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceLeftBody50kHzX;

/// 左半身50kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceLeftBody50kHzXUnit;

/// 右半身50kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceRightBody50kHzX;

/// 右半身50kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceRightBody50kHzXUnit;

/// 両腕50kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceArms50kHzX;

/// 両腕50kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceArms50kHzXUnit;

/// 左腕6.25kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceLeftArm6_25kHzR;

/// 左腕6.25kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceLeftArm6_25kHzRUnit;

/// 右腕6.25kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceRightArm6_25kHzR;

/// 右腕6.25kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceRightArm6_25kHzRUnit;

/// 左足6.25kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceLeftFoot6_25kHzR;

/// 左足6.25kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceLeftFoot6_25kHzRUnit;

/// 右足6.25kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceRightFoot6_25kHzR;

/// 右足6.25kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceRightFoot6_25kHzRUnit;

/// 左半身6.25kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceLeftBody6_25kHzR;

/// 左半身6.25kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceLeftBody6_25kHzRUnit;

/// 右半身6.25kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceRightBody6_25kHzR;

/// 右半身6.25kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceRightBody6_25kHzRUnit;

/// 両腕6.25kHzRを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceArms6_25kHzR;

/// 両腕6.25kHzRの単位を表します。
@property (nonatomic, readonly) NSString *impedanceArms6_25kHzRUnit;

/// 左腕6.25kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceLeftArm6_25kHzX;

/// 左腕6.25kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceLeftArm6_25kHzXUnit;

/// 右腕6.25kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceRightArm6_25kHzX;

/// 右腕6.25kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceRightArm6_25kHzXUnit;

/// 左足6.25kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceLeftFoot6_25kHzX;

/// 左足6.25kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceLeftFoot6_25kHzXUnit;

/// 右足6.25kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceRightFoot6_25kHzX;

/// 右足6.25kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceRightFoot6_25kHzXUnit;

/// 左半身6.25kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceLeftBody6_25kHzX;

/// 左半身6.25kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceLeftBody6_25kHzXUnit;

/// 右半身6.25kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceRightBody6_25kHzX;

/// 右半身6.25kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceRightBody6_25kHzXUnit;

/// 両腕6.25kHzXを表します。範囲:-3276.8～3276.7 (0.1ohm単位)。
@property (nonatomic, copy)     NSString *impedanceArms6_25kHzX;

/// 両腕6.25kHzXの単位を表します。
@property (nonatomic, readonly) NSString *impedanceArms6_25kHzXUnit;


/**
 * 走行歩数リストを表します。
 * 24時間分のデータ（NSString*）が0時から23時の順に格納されています。
 */
@property (nonatomic, copy)     NSArray *stepsRunningArray;

/// 走行歩数リストの単位を表します。
@property (nonatomic, readonly) NSString *stepsRunningUnit;

/**
 * 歩行歩数リストを表します。
 * 24時間分のデータ（NSString*）が0時から23時の順に格納されています。
 */
@property (nonatomic, copy)     NSArray *stepsWalkingArray;

/// 歩行歩数リストの単位を表します。
@property (nonatomic, readonly) NSString *stepsWalkingUnit;

/// 計測日時を表します。
@property (nonatomic, copy)     NSDate *date;

/// 体型を表します。
@property (nonatomic)           TNTFigure figure;

/// 身長を表します。
@property (nonatomic, copy)     NSString *height;

/// 身長の単位を表します。
@property (nonatomic, readonly) NSString *heightUnit;

/// 生活強度を表します。
@property (nonatomic)           UInt8 activityLevel;

/// 体水分率を表します。
@property (nonatomic, copy)     NSString *bodyWater;

/// 体水分率の単位を表します。
@property (nonatomic, readonly) NSString *bodyWaterUnit;

/// 筋肉量を表します。
@property (nonatomic, copy)     NSString *muscleMass;

/// 筋肉量の単位を表します。
@property (nonatomic, readonly) NSString *muscleMassUnit;

/// 筋肉量スコアを表します。
@property (nonatomic)           SInt8 muscleMassScore;

/// 筋肉量判定(全身）を表します。
@property (nonatomic)           UInt8 muscleMassJudgement;

/// 推定骨量を表します。
@property (nonatomic, copy)     NSString *boneMass;

/// 推定骨量の単位を表します。
@property (nonatomic, readonly) NSString *boneMassUnit;

/// 骨量判定を表します。
@property (nonatomic)           UInt8 boneMassJudgement;

/// 内臓脂肪を表します。
@property (nonatomic, copy)     NSString *visceralFat;

/// 内臓脂肪の単位を表します。
@property (nonatomic, readonly) NSString *visceralFatUnit;

/// 内臓脂肪レベル判定を表します。
@property (nonatomic)           UInt8 visceralFatJudgement;

/// 基礎代謝を表します。
@property (nonatomic, copy)     NSString *basalMetabolicRate;

/// 基礎代謝の単位を表します。
@property (nonatomic, readonly) NSString *basalMetabolicRateUnit;

/// DCIを表します。
@property (nonatomic, copy)     NSString *dailyCaloricIntake;

/// DCIの単位を表します。
@property (nonatomic, readonly) NSString *dailyCaloricIntakeUnit;

/// 基礎代謝判定を表します。
@property (nonatomic)           UInt8 basalMetabolicRateJudgement;

/// 体内年齢を表します。[1才単位]
@property (nonatomic)           UInt8 metabolicAge;

/// 温度カウントを表します。
@property (nonatomic, copy)     NSString *temperature;

/// 温度カウントの単位を表します。
@property (nonatomic, readonly) NSString *temperatureUnit;

/// 0点カウントを表します。
@property (nonatomic, copy)     NSString *weightZero;

/// 0点カウントの単位を表します。
@property (nonatomic, copy)     NSString *weightZeroUnit;

/// 両足50kHzRを表します。
@property (nonatomic, copy)     NSString *impedanceFoot50kHzR;

/// 両足50kHzRの単位を表します。
@property (nonatomic, copy)     NSString *impedanceFoot50kHzRUnit;

/// 両足50kHzXを表します。[0.1Ω単位]
@property (nonatomic, copy)     NSString *impedanceFoot50kHzX;

/// 両足50kHzXの単位を表します。
@property (nonatomic, copy)     NSString *impedanceFoot50kHzXUnit;

/// 両足6.25kHzRを表します。
@property (nonatomic, copy)     NSString *impedanceFoot6_25kHzR;

/// 両足6.25kHzRの単位を表します。
@property (nonatomic, copy)     NSString *impedanceFoot6_25kHzRUnit;

/// 両足6.25kHzXを表します。
@property (nonatomic, copy)     NSString *impedanceFoot6_25kHzX;

/// 両足6.25kHzXの単位を表します。
@property (nonatomic, copy)     NSString *impedanceFoot6_25kHzXUnit;

/// 歩きの歩幅を表します。
@property (nonatomic, copy)     NSString *strideLengthWalking;

/// 歩きの歩幅の単位を表します。
@property (nonatomic, readonly) NSString *strideLengthWalkingUnit;

/// 走りの歩幅を表します。
@property (nonatomic, copy)     NSString *strideLengthRunning;

/// 走りの歩幅の単位を表します。
@property (nonatomic, readonly) NSString *strideLengthRunningUnit;

/**
 * 走行活動エネルギー量リストを表します。
 * 24時間分のデータ（NSString*）が0時から23時の順に格納されています。
 */
@property (nonatomic, copy)     NSArray *activityEnergyExpenditureRunningArray;

/// 走行活動エネルギー量リストの単位を表します。
@property (nonatomic, readonly) NSString *activityEnergyExpenditureRunningUnit;

/**
 * 歩行活動エネルギー量リストを表します。
 * 24時間分のデータ（NSString*）が0時から23時の順に格納されています。
 */
@property (nonatomic, copy)     NSArray *activityEnergyExpenditureWalkingArray;

/// 歩行活動エネルギー量リストの単位を表します。
@property (nonatomic, readonly) NSString *activityEnergyExpenditureWalkingUnit;

/**
 * 生活活動エネルギー量リストを表します。
 * 24時間分のデータ（NSString*）が0時から23時の順に格納されています。
 */
@property (nonatomic, copy)     NSArray *activityEnergyExpenditureLivingArray;

/// 生活活動エネルギー量リストの単位を表します。
@property (nonatomic, readonly) NSString *activityEnergyExpenditureLivingUnit;

/**
 * 安静時 代謝量リストを表します。
 * 24時間分のデータ（NSString*）が0時から23時の順に格納されています。
 */
@property (nonatomic, copy)     NSArray *restingMetabolismArray;

/// 安静時 代謝量リストの単位を表します。
@property (nonatomic, readonly) NSString *restingMetabolismUnit;

/**
 * 走行脂肪燃焼量リストを表します。
 * 24時間分のデータ（NSString*）が0時から23時の順に格納されています。
 */
@property (nonatomic, copy)     NSArray *burningFatRunningArray;

/// 走行脂肪燃焼量リストの単位を表します。
@property (nonatomic, readonly) NSString *burningFatRunningUnit;

/**
 * 歩行脂肪燃焼量リストを表します。
 * 24時間分のデータ（NSString*）が0時から23時の順に格納されています。
 */
@property (nonatomic, copy)     NSArray *burningFatWalkingArray;

/// 歩行脂肪燃焼量リストの単位を表します。
@property (nonatomic, readonly) NSString *burningFatWalkingUnit;

/**
 * 生活脂肪燃焼量リストを表します。
 * 24時間分のデータ（NSString*）が0時から23時の順に格納されています。
 */
@property (nonatomic, copy)     NSArray *burningFatLivingArray;

/// 生活脂肪燃焼量リストの単位を表します。
@property (nonatomic, readonly) NSString *burningFatLivingUnit;

/**
 * 走行活動時間リストを表します。
 * 24時間分のデータ（NSString*）が0時から23時の順に格納されています。
 */
@property (nonatomic, copy)     NSArray *timeRunningArray;

/// 走行活動時間リストの単位を表します。
@property (nonatomic, readonly) NSString *timeRunningUnit;

/**
 * 歩行活動時間リストを表します。
 * 24時間分のデータ（NSString*）が0時から23時の順に格納されています。
 */
@property (nonatomic, copy)     NSArray *timeWalkingArray;

/// 歩行活動時間リストの単位を表します。
@property (nonatomic, readonly) NSString *timeWalkingUnit;

/**
 * 生活活動時間リストを表します。
 * 24時間分のデータ（NSString*）が0時から23時の順に格納されています。
 */
@property (nonatomic, copy)     NSArray *timeLivingArray;

/// 生活活動時間リストの単位を表します。
@property (nonatomic, readonly) NSString *timeLivingUnit;

/// 筋質点数を表します。
@property (nonatomic)           UInt8 muscleQuality;

/// 筋質判定を表します。
@property (nonatomic)           UInt8 muscleQualityJudgement;

@end
