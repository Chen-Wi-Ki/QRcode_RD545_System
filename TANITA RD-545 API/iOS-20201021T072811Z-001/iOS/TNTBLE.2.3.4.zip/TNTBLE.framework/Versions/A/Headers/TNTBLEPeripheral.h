//
// Copyright (C) 2014. TANITA Corporation.
// All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TNTType.h"
@class TNTBLEPeripheral;
@class TNTDeviceInformation;
@class TNTUserInformation;
@class TNTMeasurementInformation;

/**
 * 現在の接続状態を表します。
 */
typedef NS_ENUM(NSInteger, TNTBLEPeripheralState) {
    TNTBLEPeripheralStateDisconnected = 0,      // 非接続
    TNTBLEPeripheralStateConnecting   = 1,      // 接続中
    TNTBLEPeripheralStateConnected    = 2,      // 接続済
};

/**
 * 機器状態を表します。
 */
typedef NS_ENUM(UInt8, TNTDeviceStatus) {
    TNTDeviceStatusNormal                     = 0,   // 正常
    TNTDeviceStatusMeasurementError           = 1,   // 測定異常
    TNTDeviceStatusDeviceError                = 2,   // 機器異常
    TNTDeviceStatusAgeError                   = 3,   // 年齢エラー
    TNTDeviceStatusNoPersonalInformationError = 4,   // 個人データなし
    TNTDeviceStatusReceiveDataError           = 5,   // 受信データ異常
    TNTDeviceStatusReceiveDataOverflowError   = 6,   // 受信データオーバーフロー
    TNTDeviceStatusSequenceError              = 7,   // シーケンス異常
    TNTDeviceStatusDeviceTypeError            = 8,   // 機器種別異常
};


/**
 * TNTBLEPeripheralのデリゲートです。
 */
@protocol TNTBLEPeripheralDelegate <NSObject>

@optional

/**
 * デバイスへ切断が要求された際に呼ばれます。
 * このデリゲートが呼ばれた後にTNTBLEManager.cancelTNTBLEPeripheralConnection:で切断します。
 *
 * @param peripheral   切断するデバイス
 * @param deviceStatus 切断するデバイスの状態
 * @param error        発生したエラー（エラーがなければnilが返る）
 */
- (void)peripheral:(TNTBLEPeripheral *)peripheral didRequestDisconnectWithDeviceStatus:(TNTDeviceStatus)deviceStatus error:(NSError *)error;

/**
 * デバイスへUUIDが書き込まれた際に呼ばれます。
 *
 * @param peripheral   UUIDが書き込まれたデバイス
 * @param result       書き込みの結果
 * @param deviceStatus デバイスの状態
 * @param error        発生したエラー（エラーがなければnilが返る）
 */
- (void)peripheral:(TNTBLEPeripheral *)peripheral didSaveUUIDWithResult:(UInt8)result deviceStatus:(TNTDeviceStatus)deviceStatus error:(NSError *)error;

/**
 * デバイスから個人情報を取得した際に呼ばれます。
 *
 * @param peripheral      情報を取得したデバイス
 * @param userInformation 個人情報
 * @param deviceStatus    デバイスの状態
 * @param error           発生したエラー（エラーがなければnilが返る）
 */
- (void)peripheral:(TNTBLEPeripheral *)peripheral didRetrieveUserInformation:(TNTUserInformation *)userInformation deviceStatus:(TNTDeviceStatus)deviceStatus error:(NSError *)error;

/**
 * デバイスへ個人情報が書き込まれた際に呼ばれます。
 *
 * @param peripheral      個人情報が書き込まれたデバイス
 * @param userInformation 機器に書き込まれた個人情報
 * @param deviceStatus    デバイスの状態
 * @param error           発生したエラー（エラーがなければnilが返る）
 */
- (void)peripheral:(TNTBLEPeripheral *)peripheral didSaveUserInformation:(TNTUserInformation *)userInformation deviceStatus:(TNTDeviceStatus)deviceStatus error:(NSError *)error;

/**
 * 測定が終了した際に呼ばれます。
 *
 * @param peripheral   測定終了したデバイス
 * @param deviceStatus デバイスの状態
 * @param error        発生したエラー（エラーがなければnilが返る）
 */
- (void)peripheral:(TNTBLEPeripheral *)peripheral didFinishMeasurementWithDeviceStatus:(TNTDeviceStatus)deviceStatus error:(NSError *)error;

/**
 * 測定数の取得が終了した際に呼ばれます。
 *
 * @param peripheral   測定数を取得したデバイス
 * @param count        測定数
 * @param deviceStatus デバイスの状態
 * @param error        発生したエラー（エラーがなければnilが返る）
 */
- (void)peripheral:(TNTBLEPeripheral *)peripheral didRetrieveMeasurementCount:(UInt8)count deviceStatus:(TNTDeviceStatus)deviceStatus error:(NSError *)error;

/**
 * 測定情報の取得が終了した際に呼ばれます。
 *
 * @param peripheral             測定終了したデバイス
 * @param number                 取得した測定情報の番号
 * @param measurementInformation 測定結果
 * @param deviceStatus           デバイスの状態
 * @param error                  発生したエラー（エラーがなければnilが返る）
 */
- (void)peripheral:(TNTBLEPeripheral *)peripheral didRetrieveMeasurementInformationWithNumber:(UInt8)number measurementInformation:(TNTMeasurementInformation *)measurementInformation deviceStatus:(TNTDeviceStatus)deviceStatus error:(NSError *)error;

/**
 * RSSIの更新が終了した際に呼ばれます。
 *
 * @param peripheral RSSIを更新したデバイス
 * @param error      発生したエラー（エラーがなければnilが返る）
 */
- (void)peripheralDidUpdateRSSI:(TNTBLEPeripheral *)peripheral error:(NSError *)error;


/**
 * 機器が要求を受け付けなかった場合に呼び出されます。
 *
 * @param peripheral 要求を発行しようとしたデバイス
 * @param error      発生したエラー
 */
- (void)peripheralDidFailToRequest:(TNTBLEPeripheral *)peripheral error:(NSError *)error;

@end



/**
 * デバイスとの通信用クラス。
 */
@interface TNTBLEPeripheral : NSObject

/// TNTBLEPeripheralのイベントを受け取るデリゲートを登録します。
@property (nonatomic, weak) id<TNTBLEPeripheralDelegate> delegate;

/// デバイスを識別するための識別子を登録します。
@property (nonatomic, readonly) NSString *identifier;

/// TNTBLEPeripheralの状態を表します。
@property (readonly) TNTBLEPeripheralState state;

/// デバイスの名前を表します。
@property (nonatomic, readonly) NSString *name;

/// 受信信号強度を表します。
@property (readonly) NSNumber *RSSI;

/// 要求を受け付けることができるかどうかを表します。
@property (readonly) BOOL busy;

/**
 * デバイスへ切断を依頼します。
 */
- (void)requestDisconnect;

/**
 * デバイスへ端末のUUIDを保存します。
 *
 * @param UUID 端末のUUID
 */
- (void)saveUUID:(NSString *)UUID;

/**
 * デバイスに登録されている個人情報を読み込みます。
 *
 * @param number デバイスに登録された個人識別番号
 */
- (void)retrieveUserInformationWithNumber:(UInt8)number;

/**
 * デバイスへ個人情報を書き込みます。
 * デバイスに登録されている個人情報とパラメータで指定したものの登録日付を比較し，
 * 指定したものの方が新しければデバイスの個人情報を上書きします。
 *
 * @param userInformation 書き込む個人情報
 * @param number          デバイスに登録された個人識別番号
 */
- (void)saveUserInformation:(TNTUserInformation *)userInformation number:(UInt8)number;

/**
 * 測定を開始します（一括測定）。
 */
-(void)startMeasurement;

/**
 * 測定した情報の数を取得します。
 */
-(void)retrieveMeasurementCount;

/**
 * パラメータで指定した番号の測定情報を取得します。
 *
 * @param number 測定情報番号
 */
-(void)retrieveMeasurementInformationWithNumber:(UInt8)number;

/**
 * RSSIを取得します。
 */
- (void)readRSSI;

@end
