//
// Copyright (C) 2014. TANITA Corporation.
// All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TNTType.h"

/**
 * デバイス情報を保持するプロパティクラス
 */
@interface TNTDeviceInformation : NSObject

/// ISMNベンダーコードを表します。
@property (nonatomic, copy)     NSString *ISMNVendor;

/// ISMNモデルコードを表します。
@property (nonatomic, copy)     NSString *ISMNModel;

/// MYHシリアルNo.を表します。
@property (nonatomic, copy)     NSString *MYHSerialNumber;

/// BDアドレスを表します。
@property (nonatomic, copy)     NSString *BDAddress;

/// 機器バージョンを表します。
@property (nonatomic, copy)     NSString *softwareRevision;

/// 通信モジュールバージョンを表します。
@property (nonatomic, copy)     NSString *firmwareRevision;

/// 電池残量を表します。
@property (nonatomic, copy)     NSString *batteryLevel;

/// 電池残量の単位を表します。
@property (nonatomic, readonly) NSString *batteryLevelUnit;

/// 登録可能人数を表します。
@property (nonatomic)           UInt8 personMemory;

/// デバイスの使用国を表します。
@property (nonatomic)           TNTCountry country;

/// デバイスで使用する測定単位を表します。
@property (nonatomic)           TNTUnit unit;

/// 測定タイムアウト時間を表します。
@property (nonatomic, copy)     NSString *measurementTimeout;

/// 測定タイムアウト時間の単位を表します。
@property (nonatomic, readonly) NSString *measurementTimeoutUnit;

@end
