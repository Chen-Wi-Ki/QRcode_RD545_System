//
// Copyright (C) 2014. TANITA Corporation.
// All rights reserved.
//

/**
 * The TANITA BLE Manager Interface.
 */

#import <Foundation/Foundation.h>
#import "TNTType.h"
@class TNTBLEPeripheral;
@class TNTBLEManager;
@class TNTDeviceInformation;

/**
 * TNTBLEManagerの現在の状態を表します。
 */
typedef NS_ENUM(NSInteger, TNTBLEManagerState) {
	TNTBLEManagerStateUnknown = 0,      // 初期値
	TNTBLEManagerStateResetting,        // サービスとの接続が一時的に失われた
    TNTBLEManagerStateUnsupported,      // Bluetooth Low Energyをサポートしていない
    TNTBLEManagerStateUnauthorized,     // Bluetooth Low Energyの使用を認可されていない
    TNTBLEManagerStatePoweredOff,       // Bluetoothがオフになっている
    TNTBLEManagerStatePoweredOn,        // Bluetoothがオンで，かつ，利用可能。この状態の場合のみ，API呼び出しが有効。
};



/**
 * TNTBLEManagerのデリゲートです。
 */
@protocol TNTBLEManagerDelegate <NSObject>

@required

/**
 * TNTBLEManagerの状態を更新します。
 * TNTBLEManagerを生成した後，または，端末のBT状態が変わった時に呼び出されます。
 *
 * @param state 変更後のTNTBLEManagerの状態
 */
- (void)didUpdateTNTBLEManagerState:(TNTBLEManagerState)state;


@optional

/**
 * デバイスとの接続が完了した場合に呼び出されます。
 *
 * @param manager          デバイスとの接続が完了したことを提供するTNTBLEManager
 * @param peripheral       接続したデバイス
 * @param devieInformation 接続したデバイスの機器情報
 */
- (void)manager:(TNTBLEManager *)manager didConnectTNTBLEPeripheral:(TNTBLEPeripheral *)peripheral deviceInformation:(TNTDeviceInformation *)deviceInformation;

/**
 * デバイスが切断された場合に呼び出されます。
 *
 * @param manager    デバイスの切断を提供するTNTBLEManager
 * @param peripheral 切断されたデバイス
 * @param error      切断の際に発生したエラー（エラーがなければnilが返る）
 */
- (void)manager:(TNTBLEManager *)manager didDisconnectTNTBLEPeripheral:(TNTBLEPeripheral *)peripheral error:(NSError *)error;

/**
 * デバイスへの接続が失敗した場合に呼び出されます。
 * startPairingConnection/connectWithIdentifier:applicationUUID:はタイムアウトしないため，このメソッドは通常は呼び出されません。
 * 何らかの意図しない問題が発生した場合に呼び出されます。
 *
 * @param manager    デバイスへの接続失敗を提供するTNTBLEManager
 * @param peripheral 接続に失敗したデバイス
 * @param error      接続失敗の際に発生したエラー（エラーがなければnilが返る）
 */
- (void)manager:(TNTBLEManager *)manager didFailToConnectTNTBLEPeripheral:(TNTBLEPeripheral *)peripheral error:(NSError *)error;


/**
 * デバイスへの接続要求が無視された場合に呼び出されます。
 * （接続処理中に新たに接続要求を行った場合など）
 *
 * @param manager    デバイスへの接続要求無視を提供するTNTBLEManager
 * @param peripheral 接続要求を無視したデバイス
 * @param error      接続要求無視の際に発生したエラー（エラーがなければnilが返る）
 */
- (void)manager:(TNTBLEManager *)manager didIgnoreConnectionTNTBLEPeripheral:(TNTBLEPeripheral *)peripheral error:(NSError *)error;

@end



/**
 * デバイスとの接続用クラス
 */
@interface TNTBLEManager : NSObject

/// TNTBLEManagerのイベントを受け取るデリゲートを登録します。
@property (nonatomic, weak) id<TNTBLEManagerDelegate> delegate;

/// TNTBLEManagerの状態を表します。
@property (readonly) TNTBLEManagerState state;

/// insight機能のON/OFFを表します。
@property (nonatomic) BOOL insightLog;

/// 接続要求を受け付けることができるかどうかを表します。
@property (readonly) BOOL busy;

/**
 * TNTBLEManagerを初期化します。
 *
 * @param delegate  TNTBLEManagerからのイベントを受信するデリゲートです
 * @return 本オブジェクト
 */
- (id)initWithDelegate:(id<TNTBLEManagerDelegate>)delegate;

/**
 * デバイスとのペアリングを開始します。
 *
 * @param deviceType 機器種別
 */
- (void)startPairingConnectionWithDeviceType:(TNTDeviceType)deviceType;

/**
 * デバイスのIDとアプリケーションのUUIDを指定して接続します。
 *
 * @param identifier      接続するperipheralのIdentifier
 * @param applicationUUID createApplicationUUIDで作成したアプリケーションのUUID
 * @param deviceType      機器種別
 * @param scan            接続先のデバイスをスキャンするかどうか
 */
- (void)connectWithIdentifier:(NSString *)identifier applicationUUID:(NSString *)applicationUUID deviceType:(TNTDeviceType)deviceType withScan:(BOOL)scan;

/**
 * デバイスから切断します。
 */
- (void)cancelConnection;

/**
 * デバイス識別用のUUIDを生成します。
 */
- (NSString *)createApplicationUUID;

@end
